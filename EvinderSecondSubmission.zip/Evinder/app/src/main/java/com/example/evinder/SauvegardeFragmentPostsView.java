package com.example.evinder;

import java.util.ArrayList;

public class SauvegardeFragmentPostsView {
    public static ArrayList<Post> posts = new ArrayList<>();
    public static int indexView = 0;
}
