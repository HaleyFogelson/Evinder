package com.example.evinder;

public class SauvegardeFragmentAdd {
    public static String location;
    public static String date;
    public static String name;
    public static String description;
    public static boolean image; //change to String for the future url
}
