package com.example.evinder;

public class StoreConnection {
    public static Users connectedUser;
    public static int connectedId;
}