package com.example.evinder;

import java.util.ArrayList;

public class SauvegardeFragmentPostLiked {
    public static ArrayList<Post> postsILiked = new ArrayList<>();
}
